package pyl.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Logger {
    public static void log(String log){
        System.out.println("DEBUG-----"+log);
    }
}
